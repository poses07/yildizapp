<?php
return [
    'evolution' => [
        'instance' => 'OrionVIP',
        'base_url' => 'http://localhost:8080', // Varsayılan, kullanıcı değiştirmeli
        'api_key' => 'YOUR_API_KEY' // Varsayılan, kullanıcı değiştirmeli
    ]
];
?>