<?php
// Ana dizine gelenleri admin paneline yönlendir
header("Location: admin/index.php");
exit;
?>
